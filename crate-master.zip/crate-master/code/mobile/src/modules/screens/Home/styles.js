// Imports
import { StyleSheet } from 'react-native'

// Styles
export default StyleSheet.create({
  container: {
    flex: 1
  },
  bodyContainer: {
    flex: 1
  }
})
